﻿namespace SorveteriaApp.Application;

public class Class1
{

}
