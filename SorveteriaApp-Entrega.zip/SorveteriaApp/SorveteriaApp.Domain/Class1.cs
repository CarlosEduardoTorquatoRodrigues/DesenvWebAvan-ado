﻿namespace SorveteriaApp.Domain;

public class Class1
{

}
