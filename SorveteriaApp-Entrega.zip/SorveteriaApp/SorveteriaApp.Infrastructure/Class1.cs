﻿namespace SorveteriaApp.Infrastructure;

public class Class1
{

}
